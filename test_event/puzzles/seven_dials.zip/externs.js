/** @type{?function()} */
var puzzle_init;
